Welcome to Cassia, a .NET Terminal Services library.

For the latest information, visit the project website:
http://cassia.googlecode.com/

GETTING STARTED

You'll find the main Cassia assembly in the Bin folder and API documentation in the Doc folder.

SAMPLES

To build and run the sample console application, open the Cassia.sln solution file.

FEEDBACK

Post your questions to the Cassia mailing list at cassia-users@googlegroups.com.
Bugs and feature requests can be submitted using the Issues tab on the project website.